
// Mendapatkan elemen input tanggal
var tanggalStart = document.getElementById("tanggalstart");
var tanggalEnd = document.getElementById("tanggalend");

// Menambahkan event listener ketika nilai tanggal berubah
tanggalStart.addEventListener("change", function () {
    // Mengambil nilai dari Start Dates
    var startDate = new Date(tanggalStart.value);

    // Mengambil nilai dari End Dates
    var endDate = new Date(tanggalEnd.value);

    // Memeriksa apakah End Dates lebih kecil dari Start Dates
    if (endDate < startDate) {
        alert("End Dates tidak boleh lebih kecil dari Start Dates");
        tanggalEnd.value = ''; // Mengosongkan nilai End Dates
    }
});
